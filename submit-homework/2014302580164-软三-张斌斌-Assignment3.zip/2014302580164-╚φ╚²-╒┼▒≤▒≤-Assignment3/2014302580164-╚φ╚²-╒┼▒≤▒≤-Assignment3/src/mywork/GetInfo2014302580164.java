package mywork;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.regex.*;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

public class GetInfo2014302580164 {

	private static String sName;
	private static String sSex;
	private static String sEmail;
	private static String sIntro;
	private static String URL[] = {"http://pps.whu.edu.cn"," ","http://pps.whu.edu.cn"," ","http://pps.whu.edu.cn"," "
			,"http://pps.whu.edu.cn"," ","http://pps.whu.edu.cn"," ","http://pps.whu.edu.cn"," ","http://pps.whu.edu.cn"," "};
	
	public static void getinfo() throws Exception {
		// TODO �Զ����ɵķ������
		String url1 = "http://pps.whu.edu.cn/szdw/1/";
		HttpRequest request = HttpRequest.get(url1);
		String File = "web1.html";
		request.receive(new File (File));
		//��ȡ��ҳ��Ϣ
		File File1 = new File("web1.html");
		Document doc1 = Jsoup.parse(File1,"GBK");
		Elements e = doc1.getElementsByAttributeValue("class", "listbr").select("a[href]");
		String url_b;
		int j = 0;
		for(Element i:e){
			url_b = i.attr("href");
			URL[j] = URL[j].concat(url_b);
			j++;
		}

		WriteToMysql2014302580164 sql = new WriteToMysql2014302580164();
		sql.createTable();
		for (int i = 0;i<14;i+=2){
			HttpRequest my_request = HttpRequest.get(URL[i]);
			String my_File = "web1.html";
			my_request.receive(new File (my_File));
			//��ȡ��ҳ��Ϣ
			File my_File1 = new File("web1.html");
			Document doc = Jsoup.parse(my_File1,"GBK");
			
			
			Elements name = doc.select("[width=300]");
			sName = name.text();
					
			Element intro = doc.select("p").get(1);
			sIntro = intro.text();
			
			Elements message = doc.select("[bgcolor=#FFFFFF]");
			String sMessage = message.text();
			String regular_email = "[\\w[.-]]+@[\\w[.-]]+\\.[\\w]+";
			String regular_sex = "(��|Ů)";
			Pattern p1 = Pattern.compile(regular_email);
			Pattern p2 = Pattern.compile(regular_sex);
			Matcher m1 = p1.matcher(sMessage);
			Matcher m2 = p2.matcher(sMessage);
			while (m1.find())
			{
				sEmail = m1.group();
			}
			while (m2.find()){
				sSex = m2.group();
			}
			
			sql.insertInfo(sName, sSex, sEmail, sIntro);
		}
		System.out.println("End");
	}
	
}
