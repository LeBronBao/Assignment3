package mywork;

import java.io.IOException;

public class Main2014302580164 {
	public static void main(String[] args) throws Exception{
		GetInfo2014302580164 info = new GetInfo2014302580164();
		info.getinfo();
	}

	
}
