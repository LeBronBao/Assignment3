package mywork;
import java.sql.*;

public class WriteToMysql2014302580164 {
	
	private String sql;
	private String url = "jdbc:mysql://127.0.0.1:3306/my_schema?user=root&password=123456 ";
	//private String url = "jdbc:mysql://localhost:3306/test?user=root&password=root&useUnicode=true&characterEncoding=UTF8";
	public void createTable() throws Exception
	{
		Connection con = null;
		try{
			String driver = "com.mysql.jdbc.Driver";
			Class.forName(driver);
			con = DriverManager.getConnection(url);
			Statement stmt = con.createStatement();
			sql = "create table info(name char(20),sex char(20),email char(255),introduction text(1000),primary key (name))";
			int result = stmt.executeUpdate(sql);
		}catch(SQLException e){
			e.printStackTrace();
		}
	}
	public void insertInfo(String name,String sex,String email,String intro) throws Exception
	{
		Connection con = null;
		try {
			String driver = "com.mysql.jdbc.Driver";
			Class.forName(driver);
			con = DriverManager.getConnection(url);
			Statement stmt = con.createStatement();
			
			//info (name,sex,email,introduction)
			sql = "insert into info values(?,?,?,?)";
			PreparedStatement psql;
			psql = con.prepareStatement(sql);
			psql.setString(1, name);
			psql.setString(2, sex);
			psql.setString(3, email);
			psql.setString(4, intro);
			psql.executeUpdate();
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
}
