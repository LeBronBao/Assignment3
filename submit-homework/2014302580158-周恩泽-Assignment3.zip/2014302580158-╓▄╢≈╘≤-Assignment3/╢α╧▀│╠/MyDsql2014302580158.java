package mysqltest;

public class MyDsql2014302580158 {

	public static void main(String[] args) {
		// TODO �Զ����ɵķ������
		//long start=System.currentTimeMillis();
		Buffer bf=new Buffer();
		
		Producter p=new Producter(bf);
		Sender s=new Sender(bf);
		
		new Thread(p).start();
		new Thread(s).start();
		//long end=System.currentTimeMillis();
		//System.out.println("���̺߳�ʱ��"+(end-start)+"����");
	}

}
