package mysqltest;

public class Sender implements Runnable {

	private Buffer bf;
	
	public Sender(Buffer bf){
		super();
		this.bf=bf;
	}
	
	@Override
	public void run() {
		// TODO �Զ����ɵķ������
		for(int i=20;i<=30;i++){
			bf.senderInformation();
		}
	}

	
}