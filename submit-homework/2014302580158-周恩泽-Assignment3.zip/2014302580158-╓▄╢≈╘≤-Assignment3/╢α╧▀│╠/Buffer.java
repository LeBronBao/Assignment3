package mysqltest;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class Buffer {
	
	private String pi1;
	private String pi2;
	private String pi3;
	private String pi4;
    boolean sign=true;
	
	
	//�õ���Ϣ
	public synchronized void  getInformation(String pi1,String pi2,String pi3,String pi4){
		if(!sign){
			try {
				this.wait();
			} catch (InterruptedException e) {
				// TODO �Զ����ɵ� catch ��
				e.printStackTrace();
			}
		}
		
		
		this.pi1=pi1;
		this.pi2=pi2;
		this.pi3=pi3;
		this.pi4=pi4;
		this.notify();
		this.sign=false;
	}

	public synchronized void senderInformation(){
		if(sign){
			try {
				this.wait();
			} catch (InterruptedException e) {
				// TODO �Զ����ɵ� catch ��
				e.printStackTrace();
			}
		}
	    Connection conn=null;
	    PreparedStatement  ps=null;
		try {
			Class.forName("com.mysql.jdbc.Driver");
			 conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/test","root","123456");
			
			String sql="insert into mytable (name,mailbox,tel,intrest) value(?,?,?,?)";
			
			ps=conn.prepareStatement(sql);
			
			ps.setObject(1,pi1 );
			ps.setObject(2,pi2 );
			ps.setObject(3,pi3 );
			ps.setObject(4,pi4 );
			ps.execute();
		} catch (ClassNotFoundException e) {
			// TODO �Զ����ɵ� catch ��
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO �Զ����ɵ� catch ��
			e.printStackTrace();
		}finally{
			
				try {
					if(ps!=null){
					ps.close();
					}
				} catch (SQLException e) {
					// TODO �Զ����ɵ� catch ��
					e.printStackTrace();
				}
			
			
				try {
					if(conn!=null){
					conn.close();
					}
				} catch (SQLException e) {
					// TODO �Զ����ɵ� catch ��
					e.printStackTrace();
				}
			
		}
		this.notify();
		this.sign=true;
	}
}
