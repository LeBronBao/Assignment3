package mysqltest;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

public class InterReptile {

	//��ȡ������ҳ��Դ��
	public static String getsupurl(String supurl){
		StringBuilder suburl=new StringBuilder();
		 try {
			 
				URL url=new URL(supurl);
				BufferedReader reader=new BufferedReader(new InputStreamReader(url.openStream()));
				String content="";
				while((content=reader.readLine())!=null){
					suburl.append(content);
				}
			} catch (MalformedURLException e) {
				// TODO �Զ����ɵ� catch ��
				e.printStackTrace();
			} catch (IOException e) {
				// TODO �Զ����ɵ� catch ��
				e.printStackTrace();
			} 
			return suburl.toString();
	}
	//��ȡ�������ӵ�url��
	public static List<String> getsuburl(String suburlget,String regx){
		
		    Pattern p=Pattern.compile(regx);
	        Matcher m=p.matcher(suburlget);
	        List<String> subresult=new ArrayList<String>();
	        while(m.find()){
	        	subresult.add(m.group(1));
	        	 }
	        return subresult;
	}
	
	public static String  getNameAndTel(String strc,String regx1){
		Pattern p=Pattern.compile(regx1);
        Matcher m=p.matcher(strc);
        String g=null;
        if(m.find()){
        	g=m.group();
        }
        return g;
	}
	
	
		public static String getUrl(int index){
		// TODO �Զ����ɵķ������
        String suburlget=getsupurl("http://www.wpi.edu/academics/cs/research-interests.html");
       
        List<String> result=getsuburl( suburlget,"href=\"([\\w\\s./:]+?)\"");
      
        return result.get(index);
        }
		public static String getName(int index1) throws IOException{
			String urlStr = getUrl(index1);
		Document doc=Jsoup.connect(urlStr).get();
		String name=null;
		Elements links= doc.select("title");
		for(Element link:links){
			String linktext = link.text();
			name=linktext;
		}
		return name;
		}
		public static String getResearch(int index1) throws IOException{
			String urlStr = getUrl(index1);
			Document doc=Jsoup.connect(urlStr).get();
			String interest=null;
			Elements links= doc.select("div.col ul");
			for(Element link:links){
				String linktext = link.text();
				interest=linktext;
			}
			return interest;
			}
		//��ȡ�绰���룻
        public static String getTel(int index1){
        	String urlStr = getUrl(index1);
        	String content = getsupurl(urlStr);
        	String  Tel=getNameAndTel(content,"\\+1-\\d{3}-\\d{3}-\\d{4}");
        	return Tel;
        }
        //��ȡemail��
        public static String getmail(int index1){
        	
        	String urlStr = getUrl(index1);
        	String content = getsupurl(urlStr);
        	String  mail=getNameAndTel(content,"[a-zA-Z]+@+[a-z]{2,3}.[a-z]{2,3}");
        	return mail;
        }
		public static void main(String[] args) throws IOException {
			try {
				long start=System.currentTimeMillis();
				//��������
				Class.forName("com.mysql.jdbc.Driver");
				//��������
				Connection conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/test","root","123456");
				
				String sql="insert into mytable1 (name,mailbox,tel,intrest) value(?,?,?,?)";
				
				PreparedStatement ps=conn.prepareStatement(sql);
				for(int i=20;i<=23;i++){
				ps.setObject(1,getName(i) );
				ps.setObject(2,getmail(i) );
				ps.setObject(3,getTel(i) );
				ps.setObject(4,getResearch(i) );
				ps.execute();
				}
				
				long end=System.currentTimeMillis();
				System.out.println("���̺߳�ʱ��"+(end-start)+"����");
			} catch (ClassNotFoundException e) {
				// TODO �Զ����ɵ� catch ��
				e.printStackTrace();
			} catch (SQLException e) {
				// TODO �Զ����ɵ� catch ��
				e.printStackTrace();
			}
			/*  String name=getName(20);
	          String t=getTel(20);
	          String t1=getmail(20);
	          String t2=getResearch(20);
	          System.out.println(name);
	          System.out.println(t);
	          System.out.println(t1);
	          System.out.println(t2);*/
		}
}
