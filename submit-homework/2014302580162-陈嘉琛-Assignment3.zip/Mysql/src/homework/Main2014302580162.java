package homework;

import java.io.FileWriter;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * ���߳�
 * @author Aron
 *
 */
public class Main2014302580162 {
	public static void main(String[] args) throws SQLException, IOException, ClassNotFoundException {
		//����������
		
		Class.forName("com.mysql.jdbc.Driver");

			//��������
			long start = System.currentTimeMillis();
			Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/testjdbc","root","123456");
			String[] name= new String[76];
			String[] phone= new String[76];
			String[] email= new String[76];
			String[] research= new String[76];
			WebSpider web = new WebSpider();
			for(int i=8;i<20;i++){
				String sql="insert into TeachersInformation(Name,Phone,Email,Research) values(?,?,?,?)";
				PreparedStatement ps = conn.prepareStatement(sql);
				name[i]=web.getName(web.getTeachersUrl(i));
				phone[i] = web.getPhoneNumber(web.getTeachersUrl(i));
				email[i] = web.getEMail(web.getTeachersUrl(i));
				research[i] = web.getResearchIntrest(web.getTeachersUrl(i));
				ps.setString(1, name[i]);
				ps.setString(2, phone[i]);
				ps.setString(3, email[i]);
				ps.setString(4, research[i]);
				ps.execute();
				ps.close();
			}
			String sqlStr = "select ID,Name,Phone,Email,Research from TeachersInformation where ID>?";
			PreparedStatement ps = conn.prepareStatement(sqlStr);
			ps.setObject(1, 3);
			ResultSet rs = ps.executeQuery();
			FileWriter fw = new FileWriter("teachersInformation.txt");
			while(rs.next()){
				fw.write(rs.getString(2)+"	"+rs.getString(3)+"	"+rs.getString(4)+"	"+rs.getString(5)+"\r\n");
				
			
			}
			fw.close();
			rs.close();
			ps.close();
			
			conn.close();
			long end = System.currentTimeMillis();
			System.out.println("��ʱ��"+(end- start)+"ms");
		
	}
}
