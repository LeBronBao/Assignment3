package homework;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

public class WebSpider {
	public static String getUrlContent(String urlStr,String charset){
		StringBuilder sb = new StringBuilder(); 
		try {
			URL url = new URL(urlStr);
			try {
				BufferedReader reader = new BufferedReader(new InputStreamReader(url.openStream(),Charset.forName(charset)));
				String temp = "";
				while((temp = reader.readLine())!=null){
					sb.append(temp);
				}
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} catch (MalformedURLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return sb.toString();
	}
	public static List<String> getMatcher(String destStr,String regexStr){
		Pattern p = Pattern.compile(regexStr);
		Matcher m = p.matcher(destStr);
		List<String> result = new ArrayList<String>();
		while(m.find()){
			result.add(m.group(1));
		}
		return result;
	}
	public static String getName(String destStr) {
		
		Document doc;
		try {
			doc = Jsoup.connect(destStr).get();
			Elements links = doc.select("title");
			String linkText = "";
			for(Element link:links){
				linkText = link.text();
			}
			Pattern p = Pattern.compile("(.(?! WPI))*");
			Matcher m = p.matcher(linkText);
			List<String> name = new ArrayList<String>();
			while(m.find()){
				name.add(m.group());
			}
			return name.get(0);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			return null;
		}
		
		
		
	}
	public static String getPhoneNumber(String destStr){
		String contant = getUrlContent(destStr,"utf-8");
		//List<String> number = getMatcher(contant,"\\+\\d-\\d{3}-\\d{3}-\\d{4}");
		Pattern p = Pattern.compile("\\+\\d-\\d{3}-\\d{3}-\\d{4}");
		Matcher m = p.matcher(contant);
		List<String> number = new ArrayList<String>();
		while(m.find()){
			number.add(m.group());
		}
		
		return number.get(0);
		}
	public static String getEMail(String destStr){
		String contant = getUrlContent(destStr,"utf-8");
		Pattern p = Pattern.compile("[\\w\\-]+@[a-z0-9A-Z]+(\\.)edu");
		Matcher m = p.matcher(contant);
		List<String> email = new ArrayList<String>();
		while(m.find()){
			email.add(m.group());
		}
		
		return email.get(0);
		}
	public static String getResearchIntrest(String destStr) {
		Document doc;
		try {
			doc = Jsoup.connect(destStr).get();
			Elements links = doc.select("div.col");
			String linkText = "";
			List<String> researchIn = new ArrayList<String>();
			for(Element link:links){
				linkText = link.text();
				researchIn.add(linkText);
			}
			
			return researchIn.get(0).substring(19);
			//Pattern p = Pattern.compile("(.(?! WPI))*");
			//Matcher m = p.matcher(linkText);
			
			//while(m.find()){
				//name.add(m.group());
			//}
			//return name.get(0);
		} catch (IOException e) {
			
			// TODO Auto-generated catch block
			return null;
		}
	
		
	}
	
	public static String getTeachersUrl(int index){
		String destStr = getUrlContent("http://www.wpi.edu/academics/cs/research-interests.html","utf-8");
		List<String> list = getMatcher(destStr,"href=\"(.+?)\"");
		String techers[] = new String[76];
		for(int i=0;i<76;i++){
			techers[i] = list.get(i+18);
		}
		return techers[index];
	}
	/*
	public static void main(String[] args) throws IOException{
		String one = getTeachersUrl(0);
		System.out.println(getName(one));
		System.out.println(getResearchIntrest(one));
		System.out.println(getEMail(one)+getPhoneNumber(one));
	}*/
	
}
