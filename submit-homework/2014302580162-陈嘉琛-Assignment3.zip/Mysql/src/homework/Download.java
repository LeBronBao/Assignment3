package homework;

import java.io.IOException;
import java.sql.SQLException;

public class Download implements Runnable{
	private Database db;
	public Download(Database tdb){
		db = tdb;
	}
	@Override
	public void run() {
		// TODO Auto-generated method stub
		try {
			db.dowm();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
