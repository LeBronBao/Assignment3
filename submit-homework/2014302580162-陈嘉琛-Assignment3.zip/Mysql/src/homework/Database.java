package homework;

import java.io.FileWriter;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/**
 * ���߳�
 * @author Aron
 *
 */
public class Database {
		private boolean flag= true;
		private Connection conn;
		public Database() {
				//����������
				try {
					Class.forName("com.mysql.jdbc.Driver");
					try {
						conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/testjdbc","root","123456");
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				} catch (ClassNotFoundException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
				
				
				 
	
		public synchronized void upload() throws SQLException, InterruptedException{
			if(!flag){
				try {
					this.wait();
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
				
				String[] name= new String[76];
				String[] phone= new String[76];
				String[] email= new String[76];
				String[] research= new String[76];
				WebSpider web = new WebSpider();
				for(int i=20;i<30;i++){
					String sql="insert into TeachersInformation(Name,Phone,Email,Research) values(?,?,?,?)";
					PreparedStatement ps = conn.prepareStatement(sql);
					name[i]=web.getName(web.getTeachersUrl(i));
					phone[i] = web.getPhoneNumber(web.getTeachersUrl(i));
					email[i] = web.getEMail(web.getTeachersUrl(i));
					research[i] = web.getResearchIntrest(web.getTeachersUrl(i));
					ps.setString(1, name[i]);
					ps.setString(2, phone[i]);
					ps.setString(3, email[i]);
					ps.setString(4, research[i]);
					ps.execute();
					ps.close();
					}
				this.flag = false;
				
		}
	public synchronized void dowm() throws SQLException, IOException{
			if(flag){
				try {
					this.wait();
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			
			
			
			String sqlStr = "select ID,Name,Phone,Email,Research from TeachersInformation where ID>?";
			PreparedStatement ps = conn.prepareStatement(sqlStr);
			ps.setObject(1, 3);
			ResultSet rs = ps.executeQuery();
			FileWriter fw = new FileWriter("teachersInformation.txt");
			while(rs.next()){
				fw.write(rs.getString(2)+"	"+rs.getString(3)+"	"+rs.getString(4)+"	"+rs.getString(5)+"\r\n");
					
				
				}
			fw.close();
			rs.close();
			ps.close();
			this.notifyAll();
			this.flag = true;
			}
				
}

