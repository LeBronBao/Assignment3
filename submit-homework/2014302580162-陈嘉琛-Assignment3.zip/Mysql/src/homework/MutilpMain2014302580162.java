package homework;

import java.sql.SQLException;
import java.util.concurrent.CountDownLatch;

public class MutilpMain2014302580162 {
	private static Database db = new Database();
	public static void main(String[] args){
		
		Upload u = new Upload(db);
		Download d = new Download(db);
		new Thread(u).start();
		new Thread(d).start();
		}
			
}
