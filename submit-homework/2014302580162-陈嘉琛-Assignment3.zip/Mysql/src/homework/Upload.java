package homework;

import java.sql.SQLException;

public class Upload implements Runnable{
	private Database db;
	private long startTime;
	private long endTime;
	public Upload(Database tdb){
		db = tdb;
	}
	@Override
	public void run() {
	
		try {
			try {
				db.upload();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	
	}

}
